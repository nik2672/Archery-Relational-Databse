<?php
require("settings.php");
$conn = @mysqli_connect($host, $user, $pwd, $sql_db);

$tableName = $_GET['table'];
$sql = "SHOW COLUMNS FROM `$tableName`";

$result = mysqli_query($conn, $sql);

$columns = [];
while ($row = mysqli_fetch_assoc($result)) {

  $columns[] = $row['Field'];
}

echo json_encode($columns);
