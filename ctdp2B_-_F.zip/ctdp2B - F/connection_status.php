<?php
require("settings.php");
$conn = @mysqli_connect($host, $user, $pwd, $sql_db);

if (!$conn) {
  echo "Database connection failed.";
} else {
  echo "Database connection successful.";
}
?>