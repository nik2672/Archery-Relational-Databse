<?php
session_start();
require("settings.php");
$conn = @mysqli_connect($host, $user, $pwd, $sql_db);

if (
    !isset($_POST['archer_id']) || 
    !isset($_POST['date']) || 
    !isset($_POST['round']) || 
    !isset($_POST['comp_id']) || 
    !isset($_POST['range_id']) || 
    !isset($_POST['total_score']) || 
    !isset($_POST['is_personal_best'])
) {
    echo "All fields are required.";
    exit;
}

$archer_id = $_POST['archer_id'];
$date = $_POST['date'];
$round = $_POST['round'];
$comp_id = $_POST['comp_id'];
$range_id = $_POST['range_id'];
$total_score = $_POST['total_score'];
$is_personal_best = $_POST['is_personal_best'];

$sql = "INSERT INTO Score (archer_id, date_shot, round_id, comp_id, range_id, total_score, is_personal_best) 
        VALUES ('$archer_id', '$date', '$round', '$comp_id', '$range_id', '$total_score', '$is_personal_best')";

if (mysqli_query($conn, $sql)) {
    echo "Score entered successfully.";
} else {
    echo "Error entering score: " . mysqli_error($conn);
}
?>
