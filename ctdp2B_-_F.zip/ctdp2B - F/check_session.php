<?php
session_start();
header('Content-Type: application/json');
$response = [
    'username' => isset($_SESSION['username']) ? $_SESSION['username'] : '',
    'role' => isset($_SESSION['role']) ? $_SESSION['role'] : '',
    'archer_id' => isset($_SESSION['archer_id']) ? $_SESSION['archer_id'] : ''
];
echo json_encode($response);
?>
