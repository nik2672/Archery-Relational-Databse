<?php
session_start();
require("settings.php");
$conn = @mysqli_connect($host, $user, $pwd, $sql_db);

// to insert a new archer
function insertArcher($conn) {
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $division_id = $_POST['division_id'];
    $equipment_id = $_POST['equipment_id'];

    $sql = "INSERT INTO Archer (first_name, last_name, gender, dob, email, division_id, equipment_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssi", $firstName, $lastName, $gender, $dob, $email, $division_id, $equipment_id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "New archer added successfully.";
    } else {
        echo "Error adding archer: " . $conn->error;
    }

    $stmt->close();
}

// function put in a newnew round
function insertRound($conn) {
    $comp_id = $_POST['comp_id'];
    $round_type = $_POST['round_type'];
    $no_of_ranges = $_POST['no_of_ranges'];
    $total_arrows = $_POST['total_arrows'];
    $total_possible_score = $_POST['total_possible_score'];

    $sql = "INSERT INTO Round (comp_id, round_type, no_of_ranges, total_arrows, total_possible_score)
            VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isiii", $comp_id, $round_type, $no_of_ranges, $total_arrows, $total_possible_score);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "New round added successfully.";
    } else {
        echo "Error adding round: " . $conn->error;
    }

    $stmt->close();
}

// to insert a new competition
function insertCompetition($conn) {
    $comp_name = $_POST['comp_name'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    $sql = "INSERT INTO Competition (comp_name, start_date, end_date)
            VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $comp_name, $start_date, $end_date);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "New competition added successfully.";
    } else {
        echo "Error adding competition: " . $conn->error;
    }

    $stmt->close();
}

// function to call based on thee form type
$formType = $_POST['form_type'];

if ($formType === 'archer') {
    insertArcher($conn);
} elseif ($formType === 'round') {
    insertRound($conn);
} elseif ($formType === 'competition') {
    insertCompetition($conn);
} else {
    echo "Invalid form type.";
}

$conn->close();
?>
