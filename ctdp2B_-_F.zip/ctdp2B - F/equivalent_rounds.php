<?php
require("settings.php");
$conn = @mysqli_connect($host, $user, $pwd, $sql_db);

$comp_name = $_GET['comp_name'];

$sql = "SELECT d.division_name, r1.round_type AS original_round, r2.round_type AS equivalent_round
        FROM EquivalentRound er
        JOIN Round r1 ON er.round1_id = r1.round_id
        JOIN Round r2 ON er.round2_id = r2.round_id
        JOIN Competition c ON er.comp_id = c.comp_id
        JOIN Division d ON r1.division_id = d.division_id
        WHERE c.comp_name = '$comp_name'";

$result = mysqli_query($conn, $sql);
$equivalentRounds = [];

while ($row = mysqli_fetch_assoc($result)) {
    $equivalentRounds[] = $row;
}

echo json_encode($equivalentRounds);
?>
