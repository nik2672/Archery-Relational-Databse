<<?php
session_start();
require("settings.php");
$conn = @mysqli_connect($host, $user, $pwd, $sql_db);

if (!isset($_SESSION['username'])) {
  echo "You must be logged in to create tables.";
  exit;
}

if (!$conn) {
  echo "<h1>ERROR!</h1>";
  echo "<p>Database Connection Failure</p>";
} else {
  $sql_table_division = "Division";

  $query_table_division = "CREATE TABLE IF NOT EXISTS $sql_table_division (
    division_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    division_name VARCHAR(25) NOT NULL,
    division_age VARCHAR(25) NOT NULL
  ) ENGINE=InnoDB;";

  $sql_table_equipment = "Equipment";

  $query_table_equipment = "CREATE TABLE IF NOT EXISTS $sql_table_equipment (
    equipment_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    equipment_type ENUM('Recurve', 'Compound', 'Recurve Barebow', 'Compound Barebow', 'Longbow') NOT NULL
  ) ENGINE=InnoDB;";

  $sql_table_competition = "Competition";

  $query_table_competition = "CREATE TABLE IF NOT EXISTS $sql_table_competition (
    comp_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    comp_name VARCHAR(50) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL
  ) ENGINE=InnoDB;";

  $sql_table_round = "Round";

  $query_table_round = "CREATE TABLE IF NOT EXISTS $sql_table_round (
    round_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    comp_id INT,
    INDEX compID (comp_id),
    FOREIGN KEY (comp_id) REFERENCES Competition(comp_id) ON DELETE SET NULL ON UPDATE CASCADE,
    round_type VARCHAR(25) NOT NULL,
    no_of_ranges INT NOT NULL,
    total_arrows INT NOT NULL,
    total_possible_score INT NOT NULL
  ) ENGINE=InnoDB;";

  $sql_table_range = "`Range`";

  $query_table_range = "CREATE TABLE IF NOT EXISTS $sql_table_range (
    range_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    round_id INT,
    INDEX roundID (round_id),
    FOREIGN KEY (round_id) REFERENCES Round(round_id) ON DELETE SET NULL ON UPDATE CASCADE,
    target_distance ENUM('10', '20', '30', '40', '50', '60', '70', '90') NOT NULL,
    end_count INT NOT NULL,
    target_size ENUM('80', '120') NOT NULL
  ) ENGINE=InnoDB;";

  $sql_table_archer = "Archer";

  $query_table_archer = "CREATE TABLE IF NOT EXISTS $sql_table_archer (
    archer_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(25) NOT NULL,
    last_name VARCHAR(25) NOT NULL,
    gender ENUM('Male', 'Female') NOT NULL,
    dob DATE NOT NULL,
    email VARCHAR(50) NOT NULL,
    division_id INT,
    equipment_id INT,
    INDEX divID (division_id),
    FOREIGN KEY (division_id) REFERENCES Division(division_id) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX equipID (equipment_id),
    FOREIGN KEY (equipment_id) REFERENCES Equipment(equipment_id) ON DELETE SET NULL ON UPDATE CASCADE
  ) ENGINE=InnoDB;";

  $sql_table_score = "Score";

  $query_table_score = "CREATE TABLE IF NOT EXISTS $sql_table_score (
    score_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    archer_id INT,
    comp_id INT,
    round_id INT,
    INDEX archID (archer_id),
    FOREIGN KEY (archer_id) REFERENCES Archer(archer_id) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX compID (comp_id),
    FOREIGN KEY (comp_id) REFERENCES Competition(comp_id) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX roundID (round_id),
    FOREIGN KEY (round_id) REFERENCES Round(round_id) ON DELETE SET NULL ON UPDATE CASCADE,
    total_score INT NOT NULL,
    date_shot DATE NOT NULL
  ) ENGINE=InnoDB;";

  $sql_table_end = "`End`";

  $query_table_end = "CREATE TABLE IF NOT EXISTS $sql_table_end (
    end_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    score_id INT,
    range_id INT,
    INDEX scoreID (score_id),
    FOREIGN KEY (score_id) REFERENCES Score(score_id) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX rangeID (range_id),
    FOREIGN KEY (range_id) REFERENCES `Range`(range_id) ON DELETE SET NULL ON UPDATE CASCADE,
    end_number INT NOT NULL
  ) ENGINE=InnoDB;";

  $sql_table_arrow = "Arrow";

  $query_table_arrow = "CREATE TABLE IF NOT EXISTS $sql_table_arrow (
  arrow_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  end_id INT,
  INDEX endID (end_id),
  FOREIGN KEY (end_id) REFERENCES `End`(end_id) ON DELETE SET NULL ON UPDATE CASCADE,
  score INT NOT NULL
  ) ENGINE=InnoDB;";

  $result_table_division = mysqli_query($conn, $query_table_division);
  $result_table_equipment = mysqli_query($conn, $query_table_equipment);
  $result_table_competition = mysqli_query($conn, $query_table_competition);
  $result_table_round = mysqli_query($conn, $query_table_round);
  $result_table_range = mysqli_query($conn, $query_table_range);
  $result_table_archer = mysqli_query($conn, $query_table_archer);
  $result_table_score = mysqli_query($conn, $query_table_score);
  $result_table_end = mysqli_query($conn, $query_table_end);
  $result_table_arrow = mysqli_query($conn, $query_table_arrow); 

  $success = $result_table_division && $result_table_equipment && $result_table_competition && $result_table_round && $result_table_range && $result_table_archer && $result_table_score && $result_table_end && $result_table_arrow;

  if(!$success) {
    echo "Error creating tables: " . mysqli_error($conn);
  } else {
    echo "Tables created successfully.";
  }
}
?>
