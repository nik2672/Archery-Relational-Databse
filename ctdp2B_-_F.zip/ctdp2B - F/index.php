<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Archery Club Database</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/vue@2.6.12/dist/vue.js"></script>
</head>
<body>
    <div id="app" class="container">
        <header class="hero-section text-center bg-primary text-white py-5">
            <div class="hero-content">

                <img src="HDO.webp" alt="HDO Logo">
                <h1>Welcome to The HDO Group Archery Club Database</h1>

                <p>Your one-stop solution for archery club management.</p>
            </div>
        </header>

        <div v-if="connectionStatus" id="connection-status" class="text-center my-3">{{ connectionStatus }}</div>

        <div v-if="message" class="alert" :class="{'alert-success': username, 'alert-danger': !username}">
            {{ message }}
        </div>

        <div v-if="username" class="alert alert-success">
            <h2>{{ welcomeMessage }}</h2>
            <p>Welcome, {{ username }}! Role: {{ role }}</p>
        </div>

        <form v-if="!username" id="loginForm" class="mb-3" @submit.prevent="login">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" class="form-control" id="username" v-model="loginForm.username">
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" class="form-control" id="password" v-model="loginForm.password">
            </div>
            <button type="submit" class="btn btn-primary">Login</button>
        </form>

        <form v-if="username" id="logoutForm" class="mb-3" @submit.prevent="logout">
            <button type="submit" class="btn btn-danger">Logout</button>
        </form>

        <nav class="navigation mb-3">
            <ul class="nav nav-pills justify-content-center">
                <li class="nav-item" v-for="table in tables" :key="table">
                    <button class="nav-link" @click="showTable(table)">{{ table }}</button>
                </li>
            </ul>
        </nav>

        <div class="content">
            <div class="section">
                <h2>Enter Staging Score</h2>
                <form id="enterScoreForm" @submit.prevent="enterScore">
                   <div class="form-group">
                        <label for="archerId">Archer ID:</label>
                        <input type="number" id="archerId" v-model="scoreData.archer_id" class="form-control" required>
                    </div>
                    <div class="form-group">
                      	  <label for="date">Date:</label>
                        <input type="date" id="date" v-model="scoreData.date" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="round">Round:</label>
                        <input type="number" id="round" v-model="scoreData.round" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="compId">Competition ID:</label>
                        <input type="number" id="compId" v-model="scoreData.comp_id" class="form-control" required>
                    </div>
                   <div class="form-group">
                        <label for="rangeId">Range ID:</label>
                        <input type="number" id="rangeId" v-model="scoreData.range_id" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="totalScore">Total Score:</label>
                        <input type="number" id="totalScore" v-model="scoreData.total_score" class="form-control" required>
                    </div>
                   <div class="form-group">
                        <label for="personalBest">Personal Best:</label>
                        <input type="number" id="personalBest" v-model="scoreData.is_personal_best" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit Score</button>
                </form>
           </div>

           	 <!-- add scoress section-->
            <div class="section">
                <h2>Enter Score</h2>
                <form id="enterScoreForm" @submit.prevent="enterScore">
                    <div class="form-group">
                        <label for="archerId">Archer ID:</label>
                        <input type="number" id="archerId" v-model="newScore.archer_id" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="date">Date:</label>
                        <input type="date" id="date" v-model="newScore.date" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="round">Round:</label>
                        <input type="number" id="round" v-model="newScore.round" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="compId">Competition ID:</label>
                        <input type="number" id="compId" v-model="newScore.comp_id" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="rangeId">Range ID:</label>
                        <input type="number" id="rangeId" v-model="newScore.range_id" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="totalScore">Total Score:</label>
                        <input type="number" id="totalScore" v-model="newScore.total_score" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="personalBest">Personal Best:</label>
                        <input type="number" id="personalBest" v-model="newScore.is_personal_best" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit Score</button>
                </form>
            </div>

            <div class="section">
                <h2>Filter Scores</h2>
                <form @submit.prevent="filterScores">
                    <div class="form-group">
                        <label for="dateStart">Start Date:</label>
                        <input type="date" id="dateStart" v-model="filter.dateStart" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="dateEnd">End Date:</label>
                        <input type="date" id="dateEnd" v-model="filter.dateEnd" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="roundType">Round Type:</label>
                        <input type="text" id="roundType" v-model="filter.roundType" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="orderBy">Order By:</label>
                        <select id="orderBy" v-model="filter.orderBy" class="form-control">
                            <option value="date_shot">Date</option>
                            <option value="total_score">Score</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Filter</button>
                </form>
                <div>
                    <h3>Scores:</h3>
                    <ul>
                        <li v-for="score in scores" :key="score.id">
                            {{ score.date_shot }} - {{ score.round_type }} - {{ score.total_score }}
                        </li>
                    </ul>
                </div>
            </div>

            <div class="section">
                <h2>Add Archer</h2>
                <form id="addArcherForm" @submit.prevent="addArcher">
                    <div class="form-group">
                        <label for="firstName">First Name:</label>
                        <input type="text" id="firstName" v-model="newArcher.firstName" name="firstName" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="lastName">Last Name:</label>
                        <input type="text" id="lastName" v-model="newArcher.lastName" name="lastName" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="gender">Gender:</label>
                        <input type="text" id="gender" v-model="newArcher.gender" name="gender" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="dob">Date of Birth:</label>
                        <input type="date" id="dob" v-model="newArcher.dob" name="dob" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" v-model="newArcher.email" name="email" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="division_id">Division ID:</label>
                        <input type="text" id="division_id" v-model="newArcher.division_id" name="division_id" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="equipment_id">Equipment ID:</label>
                        <input type="text" id="equipment_id" v-model="newArcher.equipment_id" name="equipment_id" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-primary">Add Archer</button>
                </form>
            </div>

            <!-- add round section -->
            <div class="section">
                <h2>Add Round</h2>
                <form id="addRoundForm" @submit.prevent="addRound">
                    <div class="form-group">
                        <label for="comp_id">Competition ID:</label>
                        <input type="text" id="comp_id" v-model="newRound.comp_id" name="comp_id" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="round_type">Round Type:</label>
                        <input type="text" id="round_type" v-model="newRound.round_type" name="round_type" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="no_of_ranges">Number of Ranges:</label>
                        <input type="text" id="no_of_ranges" v-model="newRound.no_of_ranges" name="no_of_ranges" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="total_arrows">Total Arrows:</label>
                        <input type="text" id="total_arrows" v-model="newRound.total_arrows" name="total_arrows" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="total_possible_score">Total Possible Score:</label>
                        <input type="text" id="total_possible_score" v-model="newRound.total_possible_score" name="total_possible_score" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-primary">Add Round</button>
                </form>
            </div>

            <!-- add competitions section-->
            <div class="section">
                <h2>Add Competition</h2>
                <form id="addCompetitionForm" @submit.prevent="addCompetition">
                    <div class="form-group">
                        <label for="comp_name">Competition Name:</label>
                        <input type="text" id="comp_name" v-model="newCompetition.comp_name" name="comp_name" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="start_date">Start Date:</label>
                        <input type="date" id="start_date" v-model="newCompetition.start_date" name="start_date" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="end_date">End Date:</label>
                        <input type="date" id="end_date" v-model="newCompetition.end_date" name="end_date" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-primary">Add Competition</button>
                </form>
            </div>

            <!-- round defintions  -->
            <div class="section">
                <h2>Round Definitions</h2>
                <button @click="getRoundDefinitions" class="btn btn-primary">Load Round Definitions</button>
                <ul v-if="showRoundDefinitions">
                    <li v-for="round in roundDefinitions" :key="round.round_id">
                        {{ round.round_type }} - Distance: {{ round.target_distance }}m, Ends: {{ round.end_count }}, Target Size: {{ round.target_size }}
                    </li>
                </ul>
            </div>

            <!-- requivelent rounds section -->
            <div class="section">
                <h2>Equivalent Rounds</h2>
                <input type="text" v-model="equivalentRoundsCompName" placeholder="Competition Name">
                <button @click="getEquivalentRounds(equivalentRoundsCompName)" class="btn btn-primary">Load Equivalent Rounds</button>
                <ul>
                    <li v-for="round in equivalentRounds" :key="round.round_id">
                        Division: {{ round.division_name }}, Original Round: {{ round.original_round }}, Equivalent Round: {{ round.equivalent_round }}
                    </li>
                </ul>
            </div>

            <!-- competition results feature -->
            <div class="section">
                <h2>Competition Results</h2>
                <input type="text" v-model="competitionResultsCompName" placeholder="Competition Name">
                <button @click="getCompetitionResults(competitionResultsCompName)" class="btn btn-primary">Load Competition Results</button>
                <ul>
                    <li v-for="result in competitionResults" :key="result.archer_id">
                        {{ result.first_name }} {{ result.last_name }} - {{ result.round_type }}: {{ result.total_score }}
                    </li>
                </ul>
            </div>

            <!-- personal best scoress-->
            <div class="section">
                <h2>Personal Best Scores</h2>
                <input type="text" v-model="personalBestArcherId" placeholder="Archer ID">
                <button @click="getPersonalBestScores(personalBestArcherId)" class="btn btn-primary">Load Personal Best Scores</button>
                <ul>
                    <li v-for="score in personalBestScores" :key="score.round_type">
                        {{ score.round_type }}: {{ score.personal_best_score }}
                    </li>
                </ul>
            </div>

            <div class="section">
                <h2>View Tables</h2>
                <p class="note">NOTE: If you cant see newly added infromation to database, please try refresh the page.</p>
                <div id="table-container" v-html="tableContent"></div>
            </div>
        </div>

        <footer class="text-center mt-4">
            &copy; The HDO Group 2023 Archery Club Database. All rights reserved.
        </footer>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="app.js"></script>
</body>
</html>
