<?php
session_start();

require("settings.php");
$conn = mysqli_connect($host, $user, $pwd, $sql_db);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT role, archer_id, score_recorder_id FROM users WHERE username = ? AND password = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $_SESSION['username'] = $username;
        $_SESSION['role'] = $row['role'];
        if ($row['archer_id']) {
            $_SESSION['archer_id'] = $row['archer_id']; // Set archer_id in session
        }

        if ($row['score_recorder_id']) {
            $_SESSION['score_recorder_id'] = $row['score_recorder_id']; // Set score_recorder_id in session
        }
        echo json_encode(['success' => true, 'message' => "Welcome $username", 'role' => $row['role']]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid username or password.']);
    }
} else {
    if (!isset($_SESSION['username'])) {
        header("Location: login_page.php"); // Redirect to a login page if not logged in
        exit;
    }
}
?>
