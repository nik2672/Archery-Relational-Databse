<?php
require("settings.php");
$conn = @mysqli_connect($host, $user, $pwd, $sql_db);



$date_start = $_GET['date_start'] ?? '';
$date_end = $_GET['date_end'] ?? '';
$round_type = $_GET['round_type'] ?? '';
$order_by = $_GET['order_by'] ?? 'date_shot';



$sql = "SELECT s.total_score, s.date_shot, r.round_type
        FROM Score s
        JOIN Archer a ON s.archer_id = a.archer_id
        JOIN Round r ON s.round_id = r.round_id
        WHERE 1=1";

if ($date_start) {
    $sql .= " AND s.date_shot >= '$date_start'";

}

if ($date_end) {
    $sql .= " AND s.date_shot <= '$date_end'";
}


if ($round_type) {
    $sql .= " AND r.round_type = '$round_type'";

}

$sql .= " ORDER BY s.$order_by DESC";

$result = mysqli_query($conn, $sql);

$scores = [];

while ($row = mysqli_fetch_assoc($result)) {
    $scores[] = $row;
}

echo json_encode($scores);
?>


