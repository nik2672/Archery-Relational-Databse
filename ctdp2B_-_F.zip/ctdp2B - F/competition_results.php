<?php
require("settings.php");
$conn = @mysqli_connect($host, $user, $pwd, $sql_db);

$comp_name = $_GET['comp_name'];

$sql = "SELECT a.first_name, a.last_name, s.total_score, r.round_type
        FROM Score s
        JOIN Archer a ON s.archer_id = a.archer_id
        JOIN Round r ON s.round_id = r.round_id
        JOIN Competition c ON s.comp_id = c.comp_id
        WHERE c.comp_name = '$comp_name'
        ORDER BY s.total_score DESC";

$result = mysqli_query($conn, $sql);
$competitionResults = [];

while ($row = mysqli_fetch_assoc($result)) {
    $competitionResults[] = $row;
}

echo json_encode($competitionResults);
?>
