new Vue({
    el: '#app',
    data: {
        connectionStatus: '',
        username: '',
        role: '',
        welcomeMessage: '',
        loginForm: {
            username: '',
            password: ''
        },
        tables: ['Archer', 'Competition', 'Round', 'Score', 'StagingScore', 'RangeEnd', 'Arrow', 'EquivalentRound', 'ClubChampion', 'Division', 'Equipment'],
        tableContent: '',
        scores: [],
        filter: {
            dateStart: '',
            dateEnd: '',
            roundType: '',
            orderBy: 'date_shot'
        },
        scoreData: {
            archer_id: '',
            date: '',
            round: '',
            comp_id: '',
            range_id: '',
            total_score: '',
            is_personal_best: ''
        },
        newScore: {
            archer_id: '',
            date: '',
            round: '',
            comp_id: '',
            range_id: '',
            total_score: '',
            is_personal_best: ''
        },
        newArcher: {
            firstName: '',
            lastName: '',
            gender: '',
            dob: '',
            email: '',
            division_id: '',
            equipment_id: ''
        },
        newRound: {
            comp_id: '',
            round_type: '',
            no_of_ranges: '',
            total_arrows: '',
            total_possible_score: ''
        },
        newCompetition: {
            comp_name: '',
            start_date: '',
            end_date: ''
        },
        message: '',
        roundDefinitions: [],
        showRoundDefinitions: false,
        equivalentRounds: [],
        equivalentRoundsCompName: '',
        competitionResults: [],
        competitionResultsCompName: '',
        personalBestScores: [],
        personalBestArcherId: ''
    },
    created() {
        this.checkConnectionStatus();
        this.checkSession();
    },
    methods: {
        checkConnectionStatus() {
            fetch('connection_status.php')
                .then(response => response.text())
                .then(status => {
                    this.connectionStatus = status;
                })
                .catch(error => {
                    this.connectionStatus = 'Error connecting to database.';
                });
        },
        checkSession() {
            fetch('check_session.php')
                .then(response => response.json())
                .then(data => {
                    if (data.username) {
                        this.username = data.username;
                        this.role = data.role;
                        this.welcomeMessage = `WELCOME ${this.role.toUpperCase()}!`;
                    }
                });
        },
        login() {
            const formData = new FormData();
            formData.append('username', this.loginForm.username);
            formData.append('password', this.loginForm.password);

            fetch('login.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    this.username = this.loginForm.username;
                    this.role = data.role;
                    this.welcomeMessage = `WELCOME ${this.role.toUpperCase()}!`;
                    this.message = data.message;
                } else {
                    this.message = data.message;
                }
            });
        },
        logout() {
            fetch('logout.php', {
                method: 'POST'
            })
            .then(() => {
                this.username = '';
            });
        },
        showTable(tableName) {
            fetch(`view_table.php?table=${tableName}`)
                .then(response => response.text())
                .then(tableData => {
                    this.tableContent = tableData.trim() === '' ? `
                        <div class="no-data-message">
                            <h3>No Data Found</h3>
                            <p>There is no data available for the ${tableName} table.</p>
                        </div>
                    ` : tableData;
                })
                .catch(error => {
                    this.tableContent = `
                        <div class="error-message">
                            <h3>Error</h3>
                            <p>An error occurred while fetching table data.</p>
                        </div>
                    `;
                });
        },
        filterScores() {
            const params = new URLSearchParams({
                date_start: this.filter.dateStart,
                date_end: this.filter.dateEnd,
                round_type: this.filter.roundType,
                order_by: this.filter.orderBy
            }).toString();

            fetch(`filter_scores.php?${params}`)
                .then(response => response.json())
                .then(data => {
                    this.scores = data;
                });
        },
        enterScore() {
            const formData = new FormData();
            formData.append('archer_id', this.newScore.archer_id);
            formData.append('date', this.newScore.date);
            formData.append('round', this.newScore.round);
            formData.append('comp_id', this.newScore.comp_id);
            formData.append('range_id', this.newScore.range_id);
            formData.append('total_score', this.newScore.total_score);
            formData.append('is_personal_best', this.newScore.is_personal_best);

            fetch('enter_score.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(alert);
        },
        addArcher() {
            const formData = new FormData(document.getElementById('addArcherForm'));
            formData.append('form_type', 'archer');

            fetch('insert_data.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(alert)
            .catch(error => console.error('Error:', error));
        },
        addRound() {
            const formData = new FormData(document.getElementById('addRoundForm'));
            formData.append('form_type', 'round');

            fetch('insert_data.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(alert)
            .catch(error => console.error('Error:', error));
        },
        addCompetition() {
            const formData = new FormData(document.getElementById('addCompetitionForm'));
            formData.append('form_type', 'competition');

            fetch('insert_data.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(alert)
            .catch(error => console.error('Error:', error));
        },
        getRoundDefinitions() {
            if (!this.showRoundDefinitions) {
                fetch('round_definitions.php')
                    .then(response => response.json())
                    .then(data => {
                        this.roundDefinitions = data;
                        this.showRoundDefinitions = true;
                    });
            } else {
                this.showRoundDefinitions = false;
            }
        },
        getEquivalentRounds(compName) {
            fetch(`equivalent_rounds.php?comp_name=${compName}`)
                .then(response => response.json())
                .then(data => {
                    this.equivalentRounds = data;
                });
        },
        getCompetitionResults(compName) {
            fetch(`competition_results.php?comp_name=${compName}`)
                .then(response => response.json())
                .then(data => {
                    this.competitionResults = data;
                });
        },
        getPersonalBestScores(archerId) {
            fetch(`personal_best.php?archer_id=${archerId}`)
                .then(response => response.json())
                .then(data => {
                    this.personalBestScores = data;
                });
        }
    }
});
